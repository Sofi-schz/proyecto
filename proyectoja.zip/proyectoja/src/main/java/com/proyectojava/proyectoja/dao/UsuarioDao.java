package com.proyectojava.proyectoja.dao;

import com.proyectojava.proyectoja.model.Usuario;

import java.util.List;

public interface UsuarioDao {

    List<Usuario> getUsuarios();
}
