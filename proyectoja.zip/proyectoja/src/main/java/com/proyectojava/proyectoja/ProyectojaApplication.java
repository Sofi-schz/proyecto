package com.proyectojava.proyectoja;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectojaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectojaApplication.class, args);
	}

}
