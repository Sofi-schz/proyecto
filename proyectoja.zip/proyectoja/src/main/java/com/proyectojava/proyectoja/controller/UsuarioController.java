package com.proyectojava.proyectoja.controller;


import com.proyectojava.proyectoja.dao.UsuarioDao;
import com.proyectojava.proyectoja.model.Usuario;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
public class UsuarioController {

    @Autowired
    private UsuarioDao usuarioDao;

    @RequestMapping(value = "usuario/{id}")
    public Usuario getUsuario(@PathVariable Long id){
        Usuario usuario = new Usuario();
        usuario.setId(id);
        usuario.setNombre("Ivette");
        usuario.setApellido("Lara");
        usuario.setDomicilio("Av cr 13 16 30");
        usuario.setTelefono("3107597399");
        return usuario;
    }

    @RequestMapping(value = "usuarios")
    public List<Usuario> getUsuarios(){
        return usuarioDao.getUsuarios();
    }

    @RequestMapping(value = "usuario45")
    public Usuario editar(){
        Usuario usuario = new Usuario();
        usuario.setNombre("Ivette");
        usuario.setApellido("Lara");
        usuario.setDomicilio("Av cr 13 16 30");
        usuario.setTelefono("3107597399");
        return usuario;
    }

    @RequestMapping(value = "usuario343")
    public Usuario eliminar(){
        Usuario usuario = new Usuario();
        usuario.setNombre("Ivette");
        usuario.setApellido("Lara");
        usuario.setDomicilio("Av cr 13 16 30");
        usuario.setTelefono("3107597399");
        return usuario;
    }


    @RequestMapping(value = "usuario123")
    public Usuario buscar(){
        Usuario usuario = new Usuario();
        usuario.setNombre("Ivette");
        usuario.setApellido("Lara");
        usuario.setDomicilio("Av cr 13 16 30");
        usuario.setTelefono("3107597399");
        return usuario;
    }

}

