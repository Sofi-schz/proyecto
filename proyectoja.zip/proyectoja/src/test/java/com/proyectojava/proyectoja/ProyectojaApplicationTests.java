package com.proyectojava.proyectoja;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectojaApplicationTests {

	@Test
	void contextLoads() {
	}

}
